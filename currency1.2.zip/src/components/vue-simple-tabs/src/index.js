import Tabs from './Tabs.vue';
import Tab from './Tab.vue';

export { Tabs, Tab };
