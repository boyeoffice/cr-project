<template>
	<div class="row">
		<div class="col-md-12">
			<div class="box box-default">
				<div class="box-body">
					<div class="dashboard">
						<div class="tabs">
							<div class="Tabs" role="tabpanel">
								<div class="Tabs-item" v-for="(data, index ) in CRYPTOCURRENCY" v-bind:class="(index === selectedCryptocurrencyIndex) && 'selected'">
									<span v-if="spotPrices[0]" class="cryptocurrency" v-on:click="getCurrency(index, data, spotPrices)">
										<span>{{ data.name }}</span><span>{{spotPrices[index].amount | currency}}</span>
									</span>
									 <span v-else class="cryptocurrency"> <span>{{ data.name }}</span></span>
								</div>
								<!-- /.Tabs-item -->
							</div>
							<!-- /.Tabs -->
							<div class="Tabs" role="tabpanel">
								<div class="Tabs-item" v-for="(data, index) in DURATION" v-bind:aria-labelledby="data.codename" tabIndex="-1"  v-on:click="getDuration(index, data)" v-bind:class="(index === selectedDurationIndex) && 'selected'">
									 <span>{{ data.codename }}</span>
								</div>
							</div>
							<!-- /.Tabs -->
						</div>
						<!-- /.tabs -->
						<div class="tabl">
							<div class="PriceTable">
								<div class="TableCell">
									<div class="value">
										<span class="large-font">{{spotPrice.amount | currency}}</span>
									</div>
									<div class="label">{{cryptocurrencyLabel}} Price</div>
								</div>
								<!-- /.TableCell -->
								<div class="TableCell" v-if="isVisible">
									<div class="value">
										<span class="large-font">{{priceDifference | currency }}</span>
									</div>
									<div class="label">{{selectedDurationData.humanize}} ({{CURRENCY[1].key}})</div>
								</div>
								<!-- /.TableCell -->
								<div class="TableCell" v-if="isVisible">
									<div class="value">
										<span class="large-font">{{percentageDifference | currency('', 2)}}</span><span class="small-font">%</span>
									</div>
									<div class="label">{{selectedDurationData.humanize}} (%)</div>
								</div>
								<!-- /.TableCell -->
							</div>
							<!-- /.PriceTable -->
						</div>
						<!-- /.tabl -->
						<div class="chart">
							<div class="topSection">
								<div class="VerticalChartAxis left">
									<div class="tick">
										{{ getVerticalPrice[0] | currency }}
									</div>
									<div class="tick">
										{{ getVerticalPrice[1] | currency }}
									</div>
								</div>
								<!-- /.VerticalChartAxis -->
							<line-chart 
							style="width: 100%;"
							 :height="76"
							:chart-data="datacollection"
							:sortPrice="sortPrice"
							:sortTime="sortTime"></line-chart>
							<div class="VerticalChartAxis right">
									<div class="tick">
										{{ getVerticalPrice[0] | currency }}
									</div>
									<div class="tick">
										{{ getVerticalPrice[1] | currency }}
									</div>
								</div>
								<!-- /.VerticalChartAxis -->
							</div>
							<!-- topSection -->
							<div class="HorizontalChartAxis">
								<div class="tick">{{xAxesTime[0]}}</div>
								<div class="tick">{{xAxesTime[1]}}</div>
							</div>
						</div>
						<!-- chart -->
					</div>
				</div>
				<!-- /.box-body -->
			</div>
			<!-- /.box-default -->
		</div>
		<!-- /.col -->
	</div>
</template>

<script>
import dashboard from '../lib/dashboard.js'
import LineChart from '../lib/LineChart.js'
export default {
	mixins: [dashboard],
	components: { LineChart }
}
</script>