 <template lang="html">
  <div class="row" v-if="! isLoading">
		<div class="col-md-12">
			<div class="box box-default">
	  		<div class="box-body">
					<div class="dashboard">
						<div class="tabs">
							<div class="Tabs" role="tabpanel">
								<div class="Tabs-item" :class="(index === selectedCryptocurrencyIndex) && 'selected'" v-for="(data, index ) in CRYPTOCURRENCY" :aria-labelledby="(data.name + ':' + ' ' + spotPrices[0].amount)">
									<span v-if="spotPrices[index].amount" @click="getCurrency(index, data, spotPrices)" class="cryptocurrency">
	                 <span>{{ data.name }}</span><span>{{spotPrices[index].amount | currency}}</span>
	                  </span>
	                  <span v-else class="cryptocurrency"> <span>{{ data.name }}</span></span>
									</div>
							</div>
							<div class="Tabs" role="tabpanel">
								<div class="Tabs-item" @click="getDuration(index, data)" :class="(index === selectedDurationIndex) && 'selected'" v-for="(data, index) in DURATION" :aria-labelledby="data.codename" tabIndex="-1">
		                 <span>{{ data.codename }}</span>
								</div>
							</div>
						</div>
						<!-- /.tabs -->
						<div class="tabl">
							<div class="PriceTable">
								<div class="TableCell">
									<div class="value">
									<span class="large-font">{{spotPrice.amount | currency}}</span>
									</div>
									<div class="label">{{cryptocurrencyLabel}} Price</div>
								</div>
								<div class="TableCell" v-if="isVisible">
									<div class="value">
									<span class="large-font">{{priceDifference | currency }}</span>
									</div>
									<div class="label">{{selectedDurationData.humanize}} ({{CURRENCY[1].key}})</div>
								</div>
								<div class="TableCell" v-if="isVisible">
									<div class="value">
									<span class="large-font">{{percentageDifference | currency('', 2)}}</span><span class="small-font">%</span>
									</div>
									<div class="label">{{selectedDurationData.humanize}} (%)</div>
								</div>
							</div>
						</div>
						<!-- /.table -->
						<div class="chart">
							<div class="topSection">
                <div class="VerticalChartAxis left">
                  <div class="tick">
                    {{maxPrice | currency}}
                  </div>
                  <div class="tick">
                    {{minPrice | currency}}
                  </div>
                </div>

               <line-chart cssClasses="PriceChart" :height="236" :width="1000" :maxPrice="maxPrice" :minPrice="minPrice" :data="moneyPrice" :dataTime="sortedTime" :dataPrice="sortedPrice"></line-chart>
               <div class="VerticalChartAxis right">
                 <div class="tick">
                   {{maxPrice | currency}}
                 </div>
                 <div class="tick">
                   {{minPrice | currency}}
                 </div>
               </div>

							</div>
              <!-- /.topSection -->
              <div class="HorizontalChartAxis">

              </div>
						</div>
					</div>
	  		</div>
	  	</div>
		</div>
  </div>
</template>

<script>
import dashboard from '../lib/dashboard.js'
import LineChart from '../lib/LineChart.js'
export default{
	mixins: [dashboard],
	components: {LineChart}
}
</script>
